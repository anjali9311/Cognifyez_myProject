# -*- coding: utf-8 -*-
"""
Created on Wed Dec  4 09:55:04 2024

@author: Anjali
"""
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import nltk
from nltk.corpus import stopwords
from nltk.sentiment.vader import SentimentIntensityAnalyzer
nltk.download('stopwords')
nltk.download('punkt')
df=pd.read_csv(r'C:\\Users\\Anjali\\Desktop\\Internships\\Cognifyez\\Dataset .csv')

print(df)


print(df.head())
reviews = df['Rating text']

nltk.download('vader_lexicon')

df['Review text'] = df['Rating text'].fillna('')

sentiment_analyzer = SentimentIntensityAnalyzer()

def get_sentiment_score(text):
    return sentiment_analyzer.polarity_scores(text)['compound']

df['Sentiment Score'] = reviews.apply(get_sentiment_score)
df['Sentiment'] = df['Sentiment Score'].apply(lambda score: 'Positive' if score >= 0 else 'Negative')

positive_keywords = {}
negative_keywords = {}

stop_words = set(stopwords.words('english'))

for index, row in df.iterrows():
    words = nltk.word_tokenize(row['Review text'].lower())
    filtered_words = [word for word in words if word.isalpha() and word not in stop_words]
    
    for word in filtered_words:
        if row['Sentiment'] == 'Positive':
            positive_keywords[word] = positive_keywords.get(word, 0) + 1
        else:
            negative_keywords[word] = negative_keywords.get(word, 0) + 1

top_positive_keywords = dict(sorted(positive_keywords.items(), key=lambda item: item[1], reverse=True)[:10])
top_negative_keywords = dict(sorted(negative_keywords.items(), key=lambda item: item[1], reverse=True)[:10])


print("Top 10 Positive Keywords:", top_positive_keywords)
print("Top 10 Negative Keywords:", top_negative_keywords)


df['Review Length'] = df['Review text'].apply(lambda x: len(nltk.word_tokenize(x)))
average_review_length = df['Review Length'].mean()

print("Average Review Length:", average_review_length)

df['Rating color'] = pd.to_numeric(df['Rating color'], errors='coerce')

average_length_by_rating = df.groupby('Rating color')['Review Length'].mean()

plt.scatter(df['Review Length'], df['Rating color'])
plt.xlabel('Review Length')
plt.ylabel('Rating color')
plt.title('Review Length vs.Rating color')
plt.show()

correlation_coefficient = df['Review Length'].corr(df['Rating color'])
print("Correlation Coefficient between Review Length and Rating color:", correlation_coefficient)


#Level3_Task2

print(df.head())

restaurant_with_highest_votes = df.loc[df["Votes"].idxmax()]

print("Restaurant with the highest number of votes:")
print(restaurant_with_highest_votes)

restaurant_with_lowest_votes = df.loc[df["Votes"].idxmin()]

print("\nRestaurant with the lowest number of votes:")
print(restaurant_with_lowest_votes)


df["Votes"] = pd.to_numeric(df["Votes"])
df["Aggregate rating"] = pd.to_numeric(df["Aggregate rating"])

correlation = df["Votes"].corr(df["Aggregate rating"])

print("\nCorrelation between number of votes and rating:", correlation)
plt.scatter(df["Votes"], df["Aggregate rating"])
plt.xlabel("Number of Votes")
plt.ylabel("Aggregate rating")
plt.title("Correlation between Number of Votes and Restaurant Rating")
plt.show()

#Level3_Task3

price_ranges = df["Price range"].unique()
online_delivery_percentages = []

for price_range in price_ranges:
    restaurants_with_delivery = df[(df["Price range"] == price_range) & (df["Has Online delivery"] == True)]
    total_restaurants = len(df[df["Price range"] == price_range])
    percentage_with_delivery = (len(restaurants_with_delivery) / total_restaurants) * 100
    online_delivery_percentages.append(percentage_with_delivery)

table_booking_percentages = []

for price_range in price_ranges:
    restaurants_with_table_booking = df[(df["Price range"] == price_range) & (df["Has Table booking"] == True)]
    total_restaurants = len(df[df["Price range"] == price_range])
    percentage_with_table_booking = (len(restaurants_with_table_booking) / total_restaurants) * 100
    table_booking_percentages.append(percentage_with_table_booking)

plt.figure(figsize=(10, 5))
plt.subplot(1, 2, 1)
plt.bar(price_ranges, online_delivery_percentages)
plt.xlabel("Price range")
plt.ylabel("Has Online delivery")
plt.title("Percentage of Restaurants with Online delivery by Price Range")





