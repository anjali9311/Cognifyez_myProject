# -*- coding: utf-8 -*-
"""
Created on Wed Dec  4 09:15:37 2024

@author: Anjali
"""

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

df=pd.read_csv(r'C:\\Users\\Anjali\\Desktop\\Internships\\Cognifyez\\Dataset .csv')
print(df)

aggregate_ratings = df['Aggregate rating']
rating_counts = aggregate_ratings.value_counts().sort_index()

most_common_rating_range = rating_counts.idxmax()
print("Most common rating range:", most_common_rating_range)


average_votes = df['Votes'].mean()
print("Average number of votes received by restaurants:", average_votes)

plt.hist(aggregate_ratings, bins=20, edgecolor='black')
plt.xlabel('Aggregate Rating')
plt.ylabel('Frequency')
plt.title('Distribution of Aggregate Ratings')
plt.show()

#Level2_Task2

cuisines = df["Cuisines"]
aggregate_ratings = df["Aggregate rating"]

cuisine_combinations_counts = cuisines.value_counts()

most_common_cuisine_combinations = cuisine_combinations_counts.head(10)
print("Most common cuisine combinations:")
print(most_common_cuisine_combinations)

cuisine_combinations_avg_rating = df.groupby("Cuisines")["Aggregate rating"].mean()

top_10_avg_ratings = cuisine_combinations_avg_rating.nlargest(10)
print("\nAverage ratings for the top 10 cuisine combinations:")
print(top_10_avg_ratings)

#Level2_Task3


import folium
from IPython.display import display
from sklearn.cluster import KMeans


restaurant_names = df["Restaurant Name"]
latitude = df["Latitude"]
longitude = df["Longitude"]


X = df[["Latitude", "Longitude"]]
num_clusters = 5

kmeans = KMeans(n_clusters=num_clusters, random_state=42)
df["Cluster"] = kmeans.fit_predict(X)

map_center = [latitude.mean(), longitude.mean()]
restaurant_map = folium.Map(location=map_center, zoom_start=12)

cluster_colors = ['red', 'blue', 'green', 'purple', 'orange']

for index, row in df.iterrows():
    restaurant_name = row["Restaurant Name"]
    latitude = row["Latitude"]
    longitude = row["Longitude"]
    cuisines = row["Cuisines"]
    rating = row["Aggregate rating"]
    cluster = row["Cluster"]

    popup_text = f"Restaurant: {restaurant_name}\nCuisines: {cuisines}\nRating: {rating}"
    marker = folium.Marker([latitude, longitude], popup=popup_text)
    marker.add_to(restaurant_map)

display(restaurant_map)


#Level3_Task4

restaurant_chains = df.groupby("Restaurant Name").size().reset_index(name="Chain Count")
restaurant_chains = restaurant_chains[restaurant_chains["Chain Count"] > 1]

restaurant_chains = restaurant_chains.sort_values(by="Chain Count", ascending=False)


plt.figure(figsize=(10, 6))
plt.bar(restaurant_chains["Restaurant Name"][:10], restaurant_chains["Chain Count"][:10])
plt.xticks(rotation=45, ha='right')
plt.xlabel("Restaurant Chain")
plt.ylabel("Number of Outlets")
plt.title("Top 10 Restaurant Chains by Number of Outlets")
plt.tight_layout()
plt.show()

chain_ratings = df.groupby("Restaurant Name")["Aggregate rating"].mean().reset_index(name="Average Rating")
chain_votes = df.groupby("Restaurant Name")["Votes"].sum().reset_index(name="Total Votes")

chain_analysis = pd.merge(chain_ratings, chain_votes, on="Restaurant Name")


chain_analysis = chain_analysis.sort_values(by="Average Rating", ascending=False)

plt.figure(figsize=(10, 6))
plt.bar(chain_analysis["Restaurant Name"][:10], chain_analysis["Average Rating"][:10])
plt.xticks(rotation=45, ha='right')
plt.xlabel("Restaurant Chain")
plt.ylabel("Average Rating")
plt.title("Top 10 Restaurant Chains by Average Rating")
plt.tight_layout()
plt.show()

plt.figure(figsize=(10, 6))
plt.bar(chain_analysis["Restaurant Name"][:10], chain_analysis["Total Votes"][:10])
plt.xticks(rotation=45, ha='right')
plt.xlabel("Restaurant Chain")
plt.ylabel("Total Votes")
plt.title("Top 10 Restaurant Chains by Total Votes")
plt.tight_layout()
plt.show()

print("Top 10 Restaurant Chains by Number of Outlets:")
print(restaurant_chains[["Restaurant Name", "Chain Count"]].head(10))

print("\nTop 10 Restaurant Chains by Total Votes:")
print(chain_analysis[["Restaurant Name", "Total Votes"]].head(10))

























