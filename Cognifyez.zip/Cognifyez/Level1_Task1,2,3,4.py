# -*- coding: utf-8 -*-
"""
Created on Wed Nov 20 19:58:15 2024

@author: Anjali
"""




import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

df=pd.read_csv(r'C:\\Users\\Anjali\\Desktop\\Internships\\Cognifyez\\Dataset .csv')

print(df)


#Level1_Task1: Top Cuisines

#Determine the top three most common cuisines in the dataset.
#Calculate the percentage of restaurants that serve each of the top cuisines.

print(df.head())

print(df.columns)

cuisine_counts = df['Cuisines'].value_counts()
print(cuisine_counts)

#Top 5 common cuisine

top_cuisines = cuisine_counts.head(5)

restaurants = len(df)
percentage = (top_cuisines/restaurants)*100

#define bar colors

colors =['Red', 'Green', 'Pink', 'Black', 'Orange']

#plot the bar

plt.bar(top_cuisines.index, top_cuisines.values, color=colors)

# Add labels and title
plt.xlabel('Cuisine')
plt.ylabel('Count')
plt.title('Top Three Cuisines')
plt.show()

plt.pie(top_cuisines.values, labels=top_cuisines.index, autopct='%1.1f%%')
plt.title('Top Three Cuisines')
plt.show()



#Level1_Task2 City Analysis

#Identify the city with the highest number of restaurants in the dataset.
#Calculate the average rating for restaurants in each city.
#Determine the city with the highest average rating.



city_counts = df['City'].value_counts()
print(city_counts)

city_with_most_restaurants = city_counts.index[0]
print(f"City with highest number of restaurants:{city_with_most_restaurants}")#f stand for formatting


average_ratings_by_city=df.groupby('City')['Aggregate rating'].mean()
print("Average ratings for restaurants in each city: ")
print(average_ratings_by_city)

city_with_highest_average_rating=average_ratings_by_city.idxmax()
print(f"City with the highest average rating:{city_with_highest_average_rating}")

#Level1_Task3 Price Range Distribution
#Create a histogram or bar chart to
#visualize the distribution of price ranges
#among the restaurants.
#Calculate the percentage of restaurants
#in each price range category

price_range_counts = df['Price range'].value_counts().sort_index()

total_restaurants = len(df)
percentage_per_price_range = (price_range_counts / total_restaurants) * 100

plt.bar(price_range_counts.index, price_range_counts.values)
plt.xlabel('Price Range')
plt.ylabel('Counts')
plt.title('Distribution of Price Ranges')
plt.show()

print("Percentage of restaurants in each price range category:")
print(percentage_per_price_range)

#Level1_Task4

total_restaurants = len(df)
restaurants_with_online_delivery = df['Has Online delivery'].value_counts().get('Yes', 0)
percentage_with_online_delivery = (restaurants_with_online_delivery / total_restaurants) * 100

print("Percentage of restaurants that offer online delivery:", percentage_with_online_delivery)


average_rating_with_online_delivery = df[df['Has Online delivery'] == 'Yes']['Aggregate rating'].mean()
average_rating_without_online_delivery = df[df['Has Online delivery'] == 'No']['Aggregate rating'].mean()

print("Average rating of restaurants with online delivery:", average_rating_with_online_delivery)
print("Average rating of restaurants without online delivery:", average_rating_without_online_delivery)


labels = ['With Online Delivery', 'Without Online Delivery']
average_ratings = [average_rating_with_online_delivery, average_rating_without_online_delivery]

plt.bar(labels, average_ratings)
plt.xlabel('Online Delivery')
plt.ylabel('Average Rating')
plt.title('Comparison of Average Ratings')
plt.show()






















